<?php
$host = 'localhost';
$dbname = 'u306792834_alshtbiDB';
$username = 'u306792834_alshtbi';
$password = 't3Q?5#F5';    

try {
    // نستخدم PDO بدلاً من mysqli لكي يتوافق مع باقي المشروع
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // إعدادات لإظهار الأخطاء بشكل واضح
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
  

} catch(PDOException $e) {
    // في حال وجود خطأ في الاتصال
    die("فشل الاتصال بقاعدة البيانات: " . $e->getMessage());
}
?>