<?php
// =======================================
// FRONT HEADER - الإصدار الخرافي النهائي
// =======================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// الاتصال بقاعدة البيانات
$db_file = __DIR__ . '/db.php';
if (file_exists($db_file)) {
    require_once $db_file;
} else {
    $db_file_alt = dirname(__DIR__) . '/db.php';
    if (file_exists($db_file_alt)) require_once $db_file_alt;
}

// حساب السلة
$cart_count = 0;
if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) $cart_count += (int)($item['quantity'] ?? 0);
}

// العملة وتغييرها
if (!isset($_SESSION['currency'])) $_SESSION['currency'] = 'YER';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['currency'])) {
    $_SESSION['currency'] = $_POST['currency'];
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// ==========================================
// 🔥 نظام تحويل العملات 🔥
// ==========================================
function formatPrice($price_in_yer) {
    $currency = $_SESSION['currency'] ?? 'YER';
    $rate_usd = 530; // 1 دولار = 530 ريال يمني 
    $rate_sar = 140; // 1 سعودي = 140 ريال يمني
    $price_in_yer = (float)$price_in_yer;

    if ($currency === 'USD') {
        $converted = $price_in_yer / $rate_usd;
        return '$' . number_format($converted, 2); 
    } elseif ($currency === 'SAR') {
        $converted = $price_in_yer / $rate_sar;
        return number_format($converted, 2) . ' ر.س'; 
    } else {
        return number_format($price_in_yer, 0) . ' ر.ي'; 
    }
}

// جلب الأقسام
try {
    $side_categories = $pdo->query("
        SELECT c.id, c.name, COUNT(p.id) as product_count 
        FROM categories c 
        LEFT JOIN products p ON c.id = p.category_id AND p.status = 1 
        GROUP BY c.id 
        ORDER BY c.name ASC
    ")->fetchAll();
} catch (Exception $e) {
    $side_categories = [];
}

// القيم الافتراضية
$default_title = 'متجر الشطبي للكيماويات';
$default_desc  = 'متجر الشطبي للمواد الكيميائية والمستلزمات الطبية والمخبرية بأفضل الأسعار في اليمن.';
$default_img   = 'https://alshatbichemical.com/assets/images/logo.png';
$current_url   = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <base href="https://alshatbichemical.com/">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? $default_title; ?></title>
    <meta name="description" content="<?php echo $pageDescription ?? $default_desc; ?>">
    <?php if(isset($pageKeywords)): ?>
    <meta name="keywords" content="<?php echo $pageKeywords; ?>">
    <?php endif; ?>
    <link rel="canonical" href="<?php echo $pageCanonical ?? $current_url; ?>">
    <!-- Open Graph / SEO -->
    <meta property="og:site_name" content="متجر الشطبي">
    <meta property="og:title" content="<?php echo $pageTitle ?? $default_title; ?>">
    <meta property="og:description" content="<?php echo $pageDescription ?? $default_desc; ?>">
    <meta property="og:type" content="<?php echo $pageType ?? 'website'; ?>">
    <meta property="og:url" content="<?php echo $pageCanonical ?? $current_url; ?>">
    <meta property="og:image" content="<?php echo $pageImage ?? $default_img; ?>">
    <meta property="og:locale" content="ar_AR">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $pageTitle ?? $default_title; ?>">
    <meta name="twitter:description" content="<?php echo $pageDescription ?? $default_desc; ?>">
    <meta name="twitter:image" content="<?php echo $pageImage ?? $default_img; ?>">
    <?php if(isset($pageSchema)): ?>
    <script type="application/ld+json"><?php echo $pageSchema; ?></script>
    <?php else: ?>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "متجر الشطبي",
      "url": "https://alshatbichemical.com/"
    }
    </script>
    <?php endif; ?>
    <!-- Bootstrap RTL & Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        /* ===== المتغيرات العامة ===== */
        :root {
            --primary-dark: #0a2647;
            --primary: #0b2f5f;
            --accent: #ffc107;
            --light-bg: #f8f9fa;
            --border-color: #e9ecef;
            --text-dark: #212529;
            --text-muted: #6c757d;
            --shadow-sm: 0 4px 20px rgba(0,0,0,0.08);
        }

        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f8f9fa;
            padding-top: 76px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* ===== Navbar ===== */
        .custom-navbar {
            background: linear-gradient(90deg, #0a2647 0%, #0b2f5f 100%);
            box-shadow: var(--shadow-sm);
            padding: 12px 0;
        }
        .navbar-nav .nav-link {
            color: rgba(255,255,255,0.9) !important;
            font-weight: 600;
            margin: 0 5px;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #ffc107 !important;
        }
        .cart-icon-wrapper {
            position: relative;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
        }
        .cart-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            font-size: 0.7rem;
            border: 2px solid #0b2f5f;
        }
        .navbar-brand {
            font-weight: 800;
            letter-spacing: -0.5px;
        }
        .dropdown-menu {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }
        .dropdown-item:hover {
            background-color: #f8f9fa;
            color: #0a2647;
        }

        /* ===== OFF-CANVAS المحسن ===== */
        .offcanvas {
            --bs-offcanvas-width: 340px;
            border: none;
        }
        .offcanvas-header.bg-gradient {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary));
            padding: 1.2rem 1.5rem;
        }
        .offcanvas-title {
            font-weight: 800;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .offcanvas .btn-close-white {
            filter: brightness(0) invert(1);
            opacity: 0.8;
        }

        /* محتوى offcanvas */
        .offcanvas-body {
            background-color: #ffffff;
            padding: 0;
            display: flex;
            flex-direction: column;
            height: 100%;
            overflow-y: auto; /* ضمان التمرير عند الحاجة */
        }

        /* قسم العملة */
        .currency-section {
            background-color: var(--light-bg);
            border-bottom: 1px solid var(--border-color);
            padding: 1rem 1.5rem;
        }
        .currency-label {
            color: var(--primary-dark);
            font-weight: 700;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }
        .currency-select {
            background-color: white;
            border: 1px solid #ced4da;
            border-radius: 30px;
            padding: 0.4rem 1.2rem;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-dark);
            cursor: pointer;
            transition: all 0.2s;
            min-width: 130px;
        }
        .currency-select:hover {
            border-color: var(--primary-dark);
        }

        /* الروابط السريعة */
        .quick-links {
            border-bottom: 1px solid var(--border-color);
        }
        .quick-link-item {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid #f1f3f5;
            font-weight: 600;
            color: var(--text-dark);
            transition: all 0.2s;
            display: flex;
            align-items: center;
            text-decoration: none;
        }
        .quick-link-item:last-child {
            border-bottom: none;
        }
        .quick-link-item i {
            width: 1.8rem;
            font-size: 1.2rem;
            color: var(--primary-dark);
            transition: transform 0.2s;
        }
        .quick-link-item:hover {
            background-color: #e7f1ff;
            color: var(--primary-dark);
            padding-right: 2rem;
        }
        .quick-link-item:hover i {
            transform: scale(1.1);
        }

        /* زر الأقسام المنسدلة */
        .categories-dropdown {
            padding: 1rem 1.5rem 0.5rem;
        }
        .categories-dropdown .dropdown-toggle {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 10px;
            padding: 0.75rem 1rem;
            font-weight: 600;
            color: #212529;
            text-align: right;
            box-shadow: none;
        }
        .categories-dropdown .dropdown-toggle:hover,
        .categories-dropdown .dropdown-toggle:focus {
            background-color: #e7f1ff;
            border-color: #0a2647;
            color: #0a2647;
        }
        .categories-dropdown .dropdown-toggle::after {
            margin-right: auto;
        }
        .categories-dropdown .dropdown-menu {
            width: 100%;
            max-height: 300px;
            overflow-y: auto;
            border-radius: 12px;
            margin-top: 5px;
            padding: 0.5rem;
            border: 1px solid #e9ecef;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .categories-dropdown .dropdown-item {
            padding: 0.6rem 1rem;
            border-radius: 8px;
            margin-bottom: 2px;
            transition: all 0.2s;
        }
        .categories-dropdown .dropdown-item:hover {
            background-color: #e7f1ff;
            transform: translateX(-3px);
        }
        .categories-dropdown .dropdown-item .badge {
            background-color: rgba(10,38,71,0.08);
            color: #0a2647;
            font-weight: 600;
            font-size: 0.75rem;
            padding: 0.3rem 0.8rem;
        }

        /* زر عرض الكل */
        .view-all-section {
            padding: 0.5rem 1.5rem 1.5rem;
        }
        .btn-view-all {
            background-color: var(--primary-dark);
            color: white;
            font-weight: 700;
            padding: 0.8rem;
            border-radius: 40px;
            transition: all 0.3s;
            border: none;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .btn-view-all:hover {
            background-color: var(--primary);
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(10,38,71,0.25);
        }

        /* روابط المستخدم */
        .user-section {
            background-color: #f1f3f5;
            border-top: 1px solid #dee2e6;
            padding: 1.5rem;
            margin-top: auto; /* تثبيت في الأسفل */
        }
        .btn-user {
            border-radius: 40px;
            font-weight: 600;
            padding: 0.6rem 1rem;
            transition: all 0.2s;
        }
        .btn-outline-secondary-custom {
            border-color: #ced4da;
            color: #495057;
        }
        .btn-outline-secondary-custom:hover {
            background-color: var(--primary-dark);
            border-color: var(--primary-dark);
            color: white;
        }
        .btn-outline-danger-custom {
            border-color: #dc3545;
            color: #dc3545;
        }
        .btn-outline-danger-custom:hover {
            background-color: #dc3545;
            color: white;
        }
        .btn-primary-custom {
            background-color: var(--primary-dark);
            border: none;
        }
        .btn-primary-custom:hover {
            background-color: var(--primary);
        }
        .btn-warning-custom {
            background-color: #ffc107;
            border: none;
            color: #212529;
        }
        .btn-warning-custom:hover {
            background-color: #e0a800;
        }

        /* تحسينات للجوال */
        @media (max-width: 576px) {
            .offcanvas {
                --bs-offcanvas-width: 85%;
            }
            .currency-select {
                min-width: 110px;
            }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg custom-navbar fixed-top">
    <div class="container">
        <a class="navbar-brand text-white fs-4 d-flex align-items-center gap-2" href="index.php">
            <i class="bi bi-mortarboard-fill text-warning"></i>
            <div>الشطبي <span class="text-warning">للكيماويات</span></div>
        </a>

        <!-- أزرار الجوال -->
        <div class="d-flex align-items-center gap-2 order-lg-2">
            <a href="cart.php" class="text-decoration-none text-white d-block d-lg-none">
                <div class="cart-icon-wrapper">
                    <i class="bi bi-cart3 fs-5"></i>
                    <?php if ($cart_count > 0): ?>
                        <span class="badge rounded-pill bg-warning text-dark cart-badge"><?php echo $cart_count; ?></span>
                    <?php endif; ?>
                </div>
            </a>
            <button class="btn btn-outline-light d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu">
                <i class="bi bi-list fs-4"></i>
            </button>
        </div>

        <!-- القائمة للشاشات الكبيرة -->
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 align-items-center p-3 p-lg-0">
                <li class="nav-item"><a class="nav-link" href="index.php">الرئيسية</a></li>
                <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item"><a class="nav-link text-warning fw-bold" href="admin/index.php"><i class="bi bi-speedometer2 ms-1"></i> لوحة التحكم</a></li>
                <?php endif; ?>

                <li class="nav-item"><a class="nav-link" href="contact.php">اتصل بنا</a></li>
            </ul>

            <div class="d-flex flex-column flex-lg-row align-items-center gap-3 mt-3 mt-lg-0 pb-3 pb-lg-0 border-top border-lg-0 border-secondary pt-3 pt-lg-0">
                <a href="cart.php" class="text-decoration-none text-white d-none d-lg-block">
                    <div class="cart-icon-wrapper">
                        <i class="bi bi-cart3 fs-5"></i>
                        <?php if ($cart_count > 0): ?>
                            <span class="badge rounded-pill bg-warning text-dark cart-badge"><?php echo $cart_count; ?></span>
                        <?php endif; ?>
                    </div>
                </a>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="dropdown">
                        <a class="nav-link dropdown-toggle text-white d-flex align-items-center gap-2 p-0" href="#" data-bs-toggle="dropdown">
                            <div class="bg-white bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center fw-bold border border-white border-opacity-25" style="width:38px; height:38px;">
                                <?php echo mb_substr($_SESSION['user_name'] ?? 'U', 0, 1, 'UTF-8'); ?>
                            </div>
                            <span class="d-none d-lg-block small opacity-75">مرحباً، <?php echo htmlspecialchars(explode(' ', $_SESSION['user_name'] ?? 'User')[0]); ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-lg">
                            <li class="px-3 py-2 text-muted small border-bottom mb-2 bg-light"><?php echo htmlspecialchars($_SESSION['email'] ?? ''); ?></li>
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                <li><a class="dropdown-item text-primary fw-bold" href="admin/index.php"><i class="bi bi-gear-fill me-2"></i>الإدارة</a></li>
                                <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person me-2"></i> حسابي</a></li>
                                <li><a class="dropdown-item" href="my_orders.php"><i class="bi bi-bag-check me-2"></i> طلباتي</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right me-2 text-danger"></i>خروج</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <div class="d-flex gap-2">
                        <a href="login.php" class="btn btn-outline-light btn-sm rounded-pill px-3">دخول</a>
                        <a href="register.php" class="btn btn-warning btn-sm rounded-pill fw-bold text-dark px-3">تسجيل</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<!-- ======================== OFF-CANVAS MENU (نسخة نهائية بلا مشاكل) ======================== -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="mobileMenu" aria-labelledby="mobileMenuLabel">
    <div class="offcanvas-header bg-gradient py-3">
        <h5 class="offcanvas-title text-white" id="mobileMenuLabel">
            <i class="bi bi-list-nested me-2"></i> القائمة
        </h5>
        <button type="button" class="btn-close btn-close-white text-reset" data-bs-dismiss="offcanvas" aria-label="إغلاق"></button>
    </div>
    <div class="offcanvas-body p-0 d-flex flex-column">

        <!-- قسم العملة (دائماً في الأعلى) -->
        <div class="currency-section">
            <div class="d-flex justify-content-between align-items-center">
                <span class="currency-label"><i class="bi bi-cash-coin"></i> العملة:</span>
                <form method="POST" class="m-0">
                    <select name="currency" class="currency-select" onchange="this.form.submit()">
                        <option value="YER" <?php if($_SESSION['currency']=='YER') echo 'selected'; ?>>🇾🇪 ريال يمني</option>
                        <option value="SAR" <?php if($_SESSION['currency']=='SAR') echo 'selected'; ?>>🇸🇦 ريال سعودي</option>
                        <option value="USD" <?php if($_SESSION['currency']=='USD') echo 'selected'; ?>>🇺🇸 دولار</option>
                    </select>
                </form>
            </div>
        </div>

        <!-- الروابط السريعة -->
        <div class="quick-links">
            <a href="index.php" class="quick-link-item">
                <i class="bi bi-house-door-fill"></i> الرئيسية
          
           
            <a href="contact.php" class="quick-link-item">
                <i class="bi bi-telephone-fill text-success"></i> اتصل بنا
            </a>
        </div>

        <!-- زر الأقسام المنسدلة -->
        <div class="categories-dropdown">
            <div class="dropdown">
                <button class="btn btn-outline-primary w-100 dropdown-toggle d-flex align-items-center justify-content-between" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <span><i class="bi bi-grid me-2"></i> تصفح حسب القسم</span>
                </button>
                <ul class="dropdown-menu w-100 p-2">
                    <?php foreach($side_categories as $cat): 
                        $icon = 'bi-tag';
                        if (strpos($cat['name'], 'كيميائية') !== false) $icon = 'bi-flask';
                        elseif (strpos($cat['name'], 'محاليل') !== false) $icon = 'bi-droplet';
                        elseif (strpos($cat['name'], 'مجسمات') !== false) $icon = 'bi-bricks';
                        elseif (strpos($cat['name'], 'أجهزة') !== false) $icon = 'bi-motherboard';
                        elseif (strpos($cat['name'], 'زجاجيات') !== false) $icon = 'bi-cup-straw';
                    ?>
                        <li>
                            <a class="dropdown-item d-flex justify-content-between align-items-center rounded-2" href="products.php?cat=<?php echo $cat['id']; ?>">
                                <span><i class="bi <?php echo $icon; ?> me-2"></i> <?php echo htmlspecialchars($cat['name']); ?></span>
                                <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill"><?php echo $cat['product_count']; ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <!-- زر عرض جميع المنتجات -->
       

        <!-- روابط المستخدم (تثبت في الأسفل تلقائياً) -->
        <div class="user-section mt-auto">
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="d-grid gap-2">
                    <a href="profile.php" class="btn btn-user btn-outline-secondary-custom"><i class="bi bi-person me-2"></i> حسابي</a>
                    <a href="my_orders.php" class="btn btn-user btn-outline-secondary-custom"><i class="bi bi-bag-check me-2"></i> طلباتي</a>
                    <a href="logout.php" class="btn btn-user btn-outline-danger-custom"><i class="bi bi-box-arrow-right me-2"></i> تسجيل خروج</a>
                </div>
            <?php else: ?>
                <div class="d-flex gap-2">
                    <a href="login.php" class="btn btn-user btn-primary-custom flex-fill"><i class="bi bi-box-arrow-in-right me-2"></i> دخول</a>
                    <a href="register.php" class="btn btn-user btn-warning-custom flex-fill"><i class="bi bi-person-plus me-2"></i> تسجيل</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<main class="flex-grow-1">
<!-- محتوى الصفحة يبدأ هنا -->