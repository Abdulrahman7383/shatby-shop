<?php
session_start();
include 'includes/db.php';
include 'includes/front_header.php';

// سعر الصرف
$rate = $pdo->query("SELECT currency_rate FROM settings WHERE id = 1")->fetchColumn() ?: 1;
$current_date = date('Y-m-d');

// جلب العروض النشطة
$sql = "
    SELECT o.*, p.name, p.description, p.image, p.price_usd, p.stock_quantity,
           c.name as category_name
    FROM offers o
    JOIN products p ON o.product_id = p.id
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE o.is_active = 1 
    AND o.start_date <= :current_date 
    AND o.end_date >= :current_date
    AND p.status = 1
    ORDER BY o.discount_percentage DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute(['current_date' => $current_date]);
$offers = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>العروض الخاصة | الشطبي</title>
    <style>
        .offer-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            border-radius: 30px;
            font-weight: bold;
            font-size: 14px;
            z-index: 1;
        }
        
        .countdown-timer {
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 10px;
            border-radius: 10px;
            text-align: center;
            margin-top: 10px;
        }
        
        .timer-item {
            display: inline-block;
            margin: 0 5px;
            padding: 5px 10px;
            background: #ffc107;
            border-radius: 5px;
            color: #000;
            font-weight: bold;
        }
        
        .original-price {
            text-decoration: line-through;
            color: #999;
            font-size: 14px;
        }
        
        .discounted-price {
            color: #dc3545;
            font-size: 18px;
            font-weight: bold;
        }
        
        .savings-badge {
            background: #28a745;
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 12px;
            margin-right: 10px;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <!-- رسالة ترحيبية -->
    <div class="hero-section bg-gradient text-white rounded-4 p-5 mb-5 text-center" 
         style="background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%);">
        <h1 class="display-5 fw-bold mb-3">🔥 العروض الحصرية</h1>
        <p class="lead mb-4">خصومات تصل إلى 70% على منتجات المختبرات والمواد الكيميائية</p>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="row g-3">
                    <div class="col-6 col-md-3">
                        <div class="bg-white text-dark rounded-3 p-3">
                            <div class="fs-1 fw-bold">🕒</div>
                            <div>عروض محدودة</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="bg-white text-dark rounded-3 p-3">
                            <div class="fs-1 fw-bold">🚚</div>
                            <div>توصيل مجاني</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="bg-white text-dark rounded-3 p-3">
                            <div class="fs-1 fw-bold">💯</div>
                            <div>جودة مضمونة</div>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="bg-white text-dark rounded-3 p-3">
                            <div class="fs-1 fw-bold">⭐</div>
                            <div>أفضل الأسعار</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- فلترة العروض -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <i class="bi bi-funnel"></i> تصفية العروض
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">نسبة الخصم</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="discount-50">
                            <label class="form-check-label" for="discount-50">
                                أكثر من 50% خصم
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="discount-30">
                            <label class="form-check-label" for="discount-30">
                                من 30% إلى 50%
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="discount-10">
                            <label class="form-check-label" for="discount-10">
                                أقل من 30%
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">وقت العرض</label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="ending-soon">
                            <label class="form-check-label" for="ending-soon">
                                🕒 تنتهي قريباً
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="new-offers">
                            <label class="form-check-label" for="new-offers">
                                🆕 عروض جديدة
                            </label>
                        </div>
                    </div>
                    
                    <button class="btn btn-primary w-100" onclick="applyFilters()">
                        تطبيق التصفية
                    </button>
                </div>
            </div>
        </div>

        <!-- قائمة العروض -->
        <div class="col-md-9">
            <?php if (empty($offers)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-tag display-1 text-muted mb-3"></i>
                    <h3 class="text-muted">لا توجد عروض حالياً</h3>
                    <p class="text-muted">تابعنا للحصول على أحدث العروض والخصومات</p>
                    <a href="index.php" class="btn btn-primary">عرض جميع المنتجات</a>
                </div>
            <?php else: ?>
                <div class="row" id="offers-container">
                    <?php foreach ($offers as $offer): 
                        $discounted_price = $offer['price_usd'] * (1 - $offer['discount_percentage'] / 100);
                        $original_price_yer = $offer['price_usd'] * $rate;
                        $discounted_price_yer = $discounted_price * $rate;
                        $savings = $original_price_yer - $discounted_price_yer;
                        
                        // حساب الوقت المتبقي
                        $end_date = new DateTime($offer['end_date']);
                        $today = new DateTime();
                        $interval = $today->diff($end_date);
                        $days_left = $interval->format('%a');
                    ?>
                        <div class="col-md-6 mb-4 offer-item" 
                             data-discount="<?php echo $offer['discount_percentage']; ?>"
                             data-days-left="<?php echo $days_left; ?>">
                            <div class="card h-100 shadow-sm position-relative">
                                <span class="offer-badge">
                                    خصم <?php echo $offer['discount_percentage']; ?>%
                                </span>
                                
                                <?php if ($days_left <= 3): ?>
                                    <span class="position-absolute top-0 end-0 m-2 badge bg-danger">
                                        🕒 تنتهي قريباً
                                    </span>
                                <?php endif; ?>
                                
                                <div class="row g-0">
                                    <div class="col-md-5">
                                        <img src="assets/uploads/<?php echo $offer['image'] ?: 'default.jpg'; ?>" 
                                             class="img-fluid rounded-start h-100" 
                                             style="object-fit: cover; height: 200px;"
                                             alt="<?php echo htmlspecialchars($offer['name']); ?>">
                                    </div>
                                    <div class="col-md-7">
                                        <div class="card-body">
                                            <h5 class="card-title fw-bold">
                                                <?php echo htmlspecialchars($offer['name']); ?>
                                            </h5>
                                            <p class="card-text text-muted small">
                                                <?php echo htmlspecialchars($offer['category_name']); ?>
                                            </p>
                                            
                                            <!-- الأسعار -->
                                            <div class="mb-3">
                                                <span class="original-price">
                                                    <?php echo number_format($original_price_yer); ?> ر.ي
                                                </span>
                                                <div class="discounted-price">
                                                    <?php echo number_format($discounted_price_yer); ?> ر.ي
                                                </div>
                                                <span class="savings-badge">
                                                    وفر <?php echo number_format($savings); ?> ر.ي
                                                </span>
                                            </div>
                                            
                                            <!-- مؤشر الوقت -->
                                            <div class="countdown-timer">
                                                <div class="small mb-1">ينتهي العرض خلال:</div>
                                                <div>
                                                    <span class="timer-item"><?php echo $days_left; ?> يوم</span>
                                                </div>
                                            </div>
                                            
                                            <!-- الأزرار -->
                                            <div class="d-grid gap-2 mt-3">
                                                <?php if ($offer['stock_quantity'] > 0): ?>
                                                    <a href="cart.php?action=add&id=<?php echo $offer['product_id']; ?>&from_offer=1" 
                                                       class="btn btn-danger">
                                                        🛒 أضف إلى السلة
                                                    </a>
                                                <?php else: ?>
                                                    <button class="btn btn-secondary" disabled>
                                                        🚫 نفذت الكمية
                                                    </button>
                                                <?php endif; ?>
                                                
                                                <a href="product_details.php?id=<?php echo $offer['product_id']; ?>" 
                                                   class="btn btn-outline-primary">
                                                    👁️ عرض التفاصيل
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function applyFilters() {
    const discount50 = document.getElementById('discount-50').checked;
    const discount30 = document.getElementById('discount-30').checked;
    const discount10 = document.getElementById('discount-10').checked;
    const endingSoon = document.getElementById('ending-soon').checked;
    const newOffers = document.getElementById('new-offers').checked;
    
    const offers = document.querySelectorAll('.offer-item');
    
    offers.forEach(offer => {
        let show = true;
        const discount = parseFloat(offer.dataset.discount);
        const daysLeft = parseInt(offer.dataset.daysLeft);
        
        // تطبيق فلاتر الخصم
        if (discount50 || discount30 || discount10) {
            show = false;
            if (discount50 && discount >= 50) show = true;
            if (discount30 && discount >= 30 && discount < 50) show = true;
            if (discount10 && discount < 30) show = true;
        }
        
        // تطبيق فلاتر الوقت
        if (endingSoon && daysLeft > 3) show = false;
        if (newOffers && daysLeft < 30) show = true;
        
        offer.style.display = show ? 'block' : 'none';
    });
}

// فرز العروض حسب الخصم
function sortByDiscount(desc = true) {
    const container = document.getElementById('offers-container');
    const offers = Array.from(container.children);
    
    offers.sort((a, b) => {
        const discountA = parseFloat(a.dataset.discount);
        const discountB = parseFloat(b.dataset.discount);
        return desc ? discountB - discountA : discountA - discountB;
    });
    
    offers.forEach(offer => container.appendChild(offer));
}

// فرز حسب الوقت المتبقي
function sortByTime() {
    const container = document.getElementById('offers-container');
    const offers = Array.from(container.children);
    
    offers.sort((a, b) => {
        const daysA = parseInt(a.dataset.daysLeft);
        const daysB = parseInt(b.dataset.daysLeft);
        return daysA - daysB;
    });
    
    offers.forEach(offer => container.appendChild(offer));
}
</script>

<?php include 'includes/footer.php'; ?>