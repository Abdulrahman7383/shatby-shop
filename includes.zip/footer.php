</main>
<footer class="modern-footer position-relative z-1">
    <!-- تأثير إضاءة خلفي متحرك -->
    <div class="footer-glow"></div>
    
    <div class="footer-top py-5">
        <div class="container">
            <div class="row g-4 align-items-center">
                
                <!-- العمود الأول: معلومات المطور والموقع -->
                <div class="col-lg-4 col-md-6 text-center text-lg-start">
                    <div class="d-inline-flex align-items-center justify-content-center justify-content-lg-start mb-3">
                        <div class="logo-icon bg-primary bg-gradient text-white rounded-4 d-flex align-items-center justify-content-center me-3 shadow-lg">
                            <i class="bi bi-flask fs-4"></i>
                        </div>
                        <div>
                            <h5 class="fw-bold text-white mb-0 fs-4">الشطبي للكيماويات</h5>
                            <span class="text-white-50 small">نظام إدارة متكامل</span>
                        </div>
                    </div>
                    <p class="text-white-50 small mb-3 lh-lg px-lg-0 px-3" style="max-width: 350px; margin-inline: auto; margin-inline-start: 0;">
                        نظام متطور لإدارة العمليات والطلبات، مصمم لتلبية احتياجات المختبر وتسهيل العمل اليومي، وتوفير كافة المستلزمات الطبية بأعلى معايير الجودة.
                    </p>
                    <div class="d-inline-flex align-items-center bg-dark bg-opacity-50 rounded-pill px-3 py-1 border border-white-10">
                        <i class="bi bi-code-slash text-primary me-2 small"></i>
                        <span class="text-white-50 small">تطوير: <span class="text-white fw-medium"> 777309160عبدالرحمن الفقيه</span></span>
                    </div>
                </div>

                <!-- العمود الثاني: روابط التواصل الاجتماعي مع رسالة -->
                <div class="col-lg-4 col-md-6 text-center">
                    <h6 class="text-white fw-bold mb-4 position-relative d-inline-block">
                        تواصل معنا
                        <span class="position-absolute bottom-0 start-50 translate-middle-x bg-primary" style="width: 50%; height: 2px;"></span>
                    </h6>
                    <div class="d-flex justify-content-center gap-3 mb-4">
                        <a href="https://wa.me/967776377797" target="_blank" class="social-icon-item bg-success-subtle text-success" title="واتساب">
                            <i class="bi bi-whatsapp"></i>
                        </a>
                        <a href="https://t.me/+967776377797" target="_blank" class="social-icon-item bg-info-subtle text-info" title="تيليجرام">
                            <i class="bi bi-telegram"></i>
                        </a>
                        <a href="mailto:info@alshatbichemical.com" class="social-icon-item bg-danger-subtle text-danger" title="بريد إلكتروني">
                            <i class="bi bi-envelope"></i>
                        </a>
                    </div>
                    <p class="text-white-50 small fst-italic">
                        نحن هنا للإجابة على استفساراتكم على مدار الساعة
                    </p>
                </div>

                <!-- العمود الثالث: بيانات الاتصال -->
                <div class="col-lg-4 col-md-12 text-center text-lg-end">
                    <h6 class="text-white fw-bold mb-4">بيانات الاتصال</h6>
                    <ul class="list-unstyled text-white-50 small">
                        <li class="mb-3 d-flex align-items-center justify-content-center justify-content-lg-end gap-2">
                            <i class="bi bi-geo-alt text-primary fs-5"></i>
                            <span>الجمهورية اليمنية، صنعاء</span>
                        </li>
                        <li class="mb-3 d-flex align-items-center justify-content-center justify-content-lg-end gap-2">
                            <i class="bi bi-telephone text-primary fs-5"></i>
                            <span dir="ltr" class="fw-medium text-white">+967 776 377 797</span>
                        </li>
                        <li class="d-flex align-items-center justify-content-center justify-content-lg-end gap-2">
                            <i class="bi bi-envelope-at text-primary fs-5"></i>
                            <span>info@alshatbichemical.com</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- الجزء السفلي -->
    <div class="footer-bottom py-4 border-top border-white-10" style="border-color: rgba(255,255,255,0.1) !important;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <p class="text-white-50 small mb-2 mb-md-0">
                        &copy; <?php echo date('Y'); ?> جميع الحقوق محفوظة لمختبر الشطبي.
                    </p>
                </div>
                
            </div>
        </div>
    </div>
</footer>

<!-- زر الواتساب العائم المحسّن -->
<div class="whatsapp-float-container">
    <a href="https://wa.me/967776377797" target="_blank" class="whatsapp-float-btn" title="تواصل معنا عبر واتساب">
        <i class="bi bi-whatsapp"></i>
    </a>
</div>

<!-- ========== بداية: إصلاح مشكلة offcanvas في الصفحة الرئيسية ========== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
// إصلاح نهائي لمشكلة offcanvas في الصفحة الرئيسية
(function() {
    // دالة لإعادة تهيئة الـ offcanvas إذا لم تكن مهيأة
    function initOffcanvas() {
        var offcanvasEl = document.getElementById('mobileMenu');
        if (offcanvasEl && !offcanvasEl._bsOffcanvas) {
            // تهيئة الـ offcanvas يدوياً
            new bootstrap.Offcanvas(offcanvasEl);
        }
    }

    // مراقبة التغييرات في DOM (لتغطية التحميل الديناميكي عبر AJAX)
    var observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                // بعد إضافة عناصر جديدة، نعيد تهيئة offcanvas
                initOffcanvas();
            }
        });
    });

    // عند تحميل الصفحة بالكامل، نبدأ المراقبة
    document.addEventListener('DOMContentLoaded', function() {
        initOffcanvas();
        observer.observe(document.body, { childList: true, subtree: true });
    });
})();
</script>
<!-- ========== نهاية: إصلاح مشكلة offcanvas ========== -->

<style>
    :root {
        --footer-bg: linear-gradient(145deg, #0b2f5f 0%, #041c33 100%);
        --footer-text: #cbd5e1;
        --footer-accent: #3b82f6;
        --whatsapp-color: #25d366;
    }

    body {
        font-family: 'Cairo', sans-serif;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    /* الفوتر الرئيسي */
    .modern-footer {
        background: var(--footer-bg);
        color: var(--footer-text);
        margin-top: auto;
        position: relative;
        overflow: hidden;
        box-shadow: 0 -10px 30px rgba(0,0,0,0.2);
    }

    /* تأثير إضاءة خلفي */
    .footer-glow {
        position: absolute;
        top: -50%;
        left: -20%;
        width: 140%;
        height: 200%;
        background: radial-gradient(circle at 30% 50%, rgba(59, 130, 246, 0.15), transparent 70%);
        opacity: 0.6;
        z-index: 0;
        animation: glowMove 15s infinite alternate ease-in-out;
    }

    @keyframes glowMove {
        0% { transform: translate(0, 0) scale(1); }
        100% { transform: translate(-5%, -5%) scale(1.1); }
    }

    .modern-footer .container {
        position: relative;
        z-index: 2;
    }

    /* أيقونة اللوجو */
    .logo-icon {
        width: 55px;
        height: 55px;
        background: linear-gradient(145deg, #2563eb, #1e40af);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .logo-icon:hover {
        transform: scale(1.1) rotate(5deg);
        box-shadow: 0 15px 25px rgba(37, 99, 235, 0.4);
    }

    /* أيقونات التواصل الاجتماعي */
    .social-icon-item {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 16px;
        font-size: 1.3rem;
        transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        text-decoration: none;
        position: relative;
        overflow: hidden;
    }

    .social-icon-item::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s;
    }

    .social-icon-item:hover::before {
        left: 100%;
    }

    .social-icon-item:hover {
        transform: translateY(-8px) scale(1.1);
        color: white !important;
        box-shadow: 0 15px 25px -5px rgba(0, 0, 0, 0.4);
    }

    .social-icon-item.bg-success-subtle:hover { background-color: #25d366 !important; }
    .social-icon-item.bg-info-subtle:hover { background-color: #0088cc !important; }
    .social-icon-item.bg-danger-subtle:hover { background-color: #ea4335 !important; }

    /* تنسيق القوائم */
    .modern-footer ul {
        padding: 0;
        margin: 0;
    }
    .modern-footer li {
        transition: transform 0.2s;
    }
    .modern-footer li:hover {
        transform: translateX(-5px);
    }
    .modern-footer li i {
        transition: transform 0.2s;
    }
    .modern-footer li:hover i {
        transform: scale(1.2);
    }

    /* رابط التذييل */
    .hover-underline {
        position: relative;
    }
    .hover-underline::after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 0;
        width: 0;
        height: 1px;
        background-color: white;
        transition: width 0.3s;
    }
    .hover-underline:hover::after {
        width: 100%;
    }

    /* زر الواتساب العائم */
    .whatsapp-float-container {
        position: fixed;
        bottom: 30px;
        right: 30px;
        z-index: 9999;
        direction: ltr;
    }

    .whatsapp-float-btn {
        width: 65px;
        height: 65px;
        background: linear-gradient(145deg, var(--whatsapp-color), #128C7E);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 34px;
        text-decoration: none;
        box-shadow: 0 10px 25px rgba(37, 211, 102, 0.4);
        transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        position: relative;
        z-index: 2;
        border: 2px solid rgba(255,255,255,0.2);
        backdrop-filter: blur(2px);
    }

    .whatsapp-float-btn:hover {
        transform: scale(1.15) rotate(10deg);
        background: linear-gradient(145deg, #20b85a, #0e6b5e);
        box-shadow: 0 15px 35px rgba(37, 211, 102, 0.6);
    }

    .whatsapp-float-btn::before {
        content: '';
        position: absolute;
        inset: -5px;
        border-radius: 50%;
        background: rgba(37, 211, 102, 0.4);
        z-index: -1;
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(0.9); opacity: 0.8; }
        70% { transform: scale(1.5); opacity: 0; }
        100% { transform: scale(1.5); opacity: 0; }
    }

    /* تحسينات الجوال */
    @media (max-width: 768px) {
        .whatsapp-float-container {
            bottom: 20px;
            right: 20px;
        }
        .whatsapp-float-btn {
            width: 55px;
            height: 55px;
            font-size: 28px;
        }
        .social-icon-item {
            width: 44px;
            height: 44px;
            font-size: 1.2rem;
        }
        .modern-footer h6 {
            margin-bottom: 1rem !important;
        }
        .footer-top {
            padding-top: 2rem !important;
            padding-bottom: 1.5rem !important;
        }
        .footer-bottom {
            padding-top: 0.75rem !important;
            padding-bottom: 0.75rem !important;
        }
    }

    /* شاشات صغيرة جداً */
    @media (max-width: 480px) {
        .whatsapp-float-container {
            bottom: 15px;
            right: 15px;
        }
        .whatsapp-float-btn {
            width: 50px;
            height: 50px;
            font-size: 26px;
        }
        .modern-footer .d-flex.gap-4 {
            gap: 1rem !important;
        }
        .modern-footer .row {
            --bs-gutter-y: 1rem;
        }
    }
</style>
</body>
</html>